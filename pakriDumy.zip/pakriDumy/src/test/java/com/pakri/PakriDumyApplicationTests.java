package com.pakri;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PakriDumyApplicationTests {

	@Test
	void contextLoads() {
	}

}
