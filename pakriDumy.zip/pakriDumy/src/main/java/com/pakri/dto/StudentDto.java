package com.pakri.dto;

import com.pakri.entities.SystemSetupEntity;
import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StudentDto {

    private String  id;
    private String name;
    private String rollNo;

    private List<SystemSetupDto> systemSetupDto;

}
