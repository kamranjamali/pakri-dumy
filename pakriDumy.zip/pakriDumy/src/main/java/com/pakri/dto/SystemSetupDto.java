package com.pakri.dto;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class SystemSetupDto {

    private String id;
    private String name;
    private String type;
    private String size;
    private String itemWeight;
    private String estimateDate;

    private String generateCode;


    private StudentDto studentDto;
}
