package com.pakri.repository;

import com.pakri.entities.SystemSetupEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SystemSetupRepository extends JpaRepository<SystemSetupEntity,Long> {


   List<SystemSetupEntity> findAllByStudentEntityId(Long studentId);
}
