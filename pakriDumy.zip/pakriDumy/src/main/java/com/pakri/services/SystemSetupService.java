package com.pakri.services;

import com.pakri.entities.SystemSetupEntity;

import java.util.List;

public interface SystemSetupService {

    SystemSetupEntity addSystemEntity(SystemSetupEntity systemSetupEntity);

    SystemSetupEntity getSystemSetupEntity(Long systemSetupEntityId);

    void deleteSystemSetupEntity(Long systemSetupEntityId);

    List<SystemSetupEntity> getAllSystemSetupEntities();

    void deleteAllEntities(List<SystemSetupEntity> setupEntityList);

    List<SystemSetupEntity> findAllByStudentEntityId(Long studentId);


//    List<SystemSetupEntity> getAllSystemSetupByIdStudentId(Long studentId);
}
