package com.pakri.services;

import com.pakri.entities.StudentEntity;

import java.util.List;

public interface StudentService {

    StudentEntity addStudent(StudentEntity studentEntity);

    StudentEntity updateStudent(StudentEntity studentEntity);

    StudentEntity getStudent(Long studentEntityId);

    List<StudentEntity> getAllStudentEntities();

    void deleteStudent(Long studentEntityId);





}
