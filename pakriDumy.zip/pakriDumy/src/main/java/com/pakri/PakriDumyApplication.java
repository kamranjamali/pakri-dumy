package com.pakri;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.Locale;

@SpringBootApplication
public class PakriDumyApplication {

	public static void main(String[] args) {
		SpringApplication.run(PakriDumyApplication.class, args);
		System.out.println("Application started");


//		for (int i = 1; i < 100; i++) {
//			String res = String.format(Locale.getDefault(), "001%03d", i);
//			System.out.println(res);
//		}

//		for (int i = 1; i < 40; i++) {
//			String res = String.format(Locale.getDefault(), "0%03d", i);
//			System.out.println(res);
//		}
	}

	@Bean
	public ModelMapper modelMapper() {
		return new ModelMapper();
	}

}
