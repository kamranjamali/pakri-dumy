package com.pakri.entities;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
public class SystemSetupEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name")
    private String name;
    @Column(name = "type")
    private String type;
    @Column(name = "size")
    private Long size;
    @Column(name = "item_weight")
    private Double itemWeight;
    @Column(name = "estimate_date")
    private Date estimateDate;

    @Transient
    private String generateCode;



    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "student_id")
    private StudentEntity studentEntity;

}
