package com.pakri.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.*;

import javax.persistence.*;
import java.util.List;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StudentEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "roll_no")
    private String rollNo;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "studentEntity",cascade = CascadeType.ALL)
    private List<SystemSetupEntity> systemSetupEntities;

}
