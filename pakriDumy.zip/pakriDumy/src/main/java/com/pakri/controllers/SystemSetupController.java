package com.pakri.controllers;

import com.pakri.dto.StatusDTO;
import com.pakri.dto.SystemSetupDto;
import com.pakri.entities.StudentEntity;
import com.pakri.entities.SystemSetupEntity;
import com.pakri.services.StudentService;
import com.pakri.services.SystemSetupService;
import com.pakri.transformer.StudentTransformer;
import com.pakri.transformer.SystemSetupTransformer;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Locale;
import java.util.Stack;

@RestController
@RequestMapping("/system")
public class SystemSetupController {

    @Autowired
    private SystemSetupService systemSetupService;

    @Autowired
    private StudentService studentService;

    @PostMapping("/create")
    ResponseEntity<StatusDTO> addSystemSetup(@ModelAttribute SystemSetupDto systemSetupDto){
        try{

            StudentEntity student = this.studentService.getStudent(Long.parseLong(systemSetupDto.getStudentDto().getId()));
            if(student == null){
                return new ResponseEntity<>(new StatusDTO(0,"Student Not Found With this ID"),HttpStatus.NOT_FOUND);
            }else {
                SystemSetupEntity systemSetupEntity= SystemSetupTransformer.getSystemSetupEntity(systemSetupDto);
                systemSetupEntity= this.systemSetupService.addSystemEntity(systemSetupEntity);
                return new ResponseEntity<>(new StatusDTO(1,"Successfully added", SystemSetupTransformer.getSystemSetupDto(systemSetupEntity)), HttpStatus.CREATED);
            }

        }catch (Exception e){
            e.printStackTrace();
            return new ResponseEntity<>(new StatusDTO(0,"This student Id does not exists !!"),HttpStatus.OK);
        }
    }

    //get single systemsetup
    @GetMapping("/{systemEntityId}")
    ResponseEntity<StatusDTO> getSystemSetupEntity(@PathVariable("systemEntityId") Long systemEntityId) {
        try {
            SystemSetupEntity systemSetupEntity = this.systemSetupService.getSystemSetupEntity(systemEntityId);
            return new ResponseEntity<>(new StatusDTO(1,"Student Found Successfully",SystemSetupTransformer.getSystemSetupDto(systemSetupEntity)),HttpStatus.OK );
        }catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(new StatusDTO(0, "System ID  Not Found!!"+e),HttpStatus.OK);
        }
    }
    //get all systems setup
    @GetMapping("/all")
    public List <SystemSetupDto> getAllSystemSetup(){
        List<SystemSetupEntity> allSystemSetupEntities = this.systemSetupService.getAllSystemSetupEntities();
        return  SystemSetupTransformer.getAllStudentDtos(allSystemSetupEntities);
    }

    @DeleteMapping("/{systemSetupEntityId}")
    ResponseEntity<StatusDTO> deleteSystemSetup(@PathVariable("systemSetupEntityId") Long systemSetupEntityId){
        try{
            SystemSetupEntity systemSetupEntity = this.systemSetupService.getSystemSetupEntity(systemSetupEntityId);
            if(systemSetupEntity == null){
                return new ResponseEntity<>(new StatusDTO(0,"System Setup ID Not Found !!"),HttpStatus.NOT_FOUND);
            }else {
                this.systemSetupService.deleteSystemSetupEntity(systemSetupEntityId);
                return new ResponseEntity<>(new StatusDTO(1,"System Setup Deleted Successfully"),HttpStatus.OK);
            }
        }catch(Exception e){
            e.printStackTrace();
            return new ResponseEntity<>(new StatusDTO(0,"System Setup ID Not Found !!"),HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/delete-all")
    ResponseEntity<StatusDTO> deleteAllSystemSetups(){
        try{
            List<SystemSetupEntity> allSystemSetupEntities = this.systemSetupService.getAllSystemSetupEntities();
            this.systemSetupService.deleteAllEntities(allSystemSetupEntities);
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseEntity<>(new StatusDTO(0, "Exception Accured !!"+e),HttpStatus.OK);
        }
        return new ResponseEntity<>(new StatusDTO(1,"All System Setup Deleted Successfully"),HttpStatus.OK);
    }


    //get all system By Student id
    @GetMapping("/getSystem/{studentId}")
     List<SystemSetupDto> getAllSystemSetupByStudentId(@PathVariable("studentId") Long studentId){
          List<SystemSetupEntity> allSystemSetupByIdStudentId = this.systemSetupService.findAllByStudentEntityId(studentId);
          List<SystemSetupDto> allStudentDtos = SystemSetupTransformer.getAllStudentDtos(allSystemSetupByIdStudentId);
         return allStudentDtos;
     }

}


//            if (systemSetupEntity == null) {
//                return new ResponseEntity<>(new StatusDTO(0, "System Setup not found"), HttpStatus.NOT_FOUND);
//            }else {
//                this.systemSetupService.deleteSystemSetupEntity(systemEntityId);
//            }
//            return new ResponseEntity<>(new StatusDTO(1,"SystemEntity Found Successfully",SystemSetupTransformer.getSystemSetupDto(systemSetupEntity)), HttpStatus.OK);
