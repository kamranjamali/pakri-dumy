package com.pakri.controllers;

import com.pakri.dto.StatusDTO;
import com.pakri.dto.StudentDto;
import com.pakri.entities.StudentEntity;
import com.pakri.services.StudentService;
import com.pakri.transformer.StudentTransformer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/student")
public class StudentEntityController {

    @Autowired
    private StudentService studentService;

    @PostMapping("/add")
    ResponseEntity<StatusDTO> addStudent(@ModelAttribute StudentDto studentDto){
       try {
           StudentEntity studentEntity = StudentTransformer.getStudentEntity(studentDto);
           studentEntity = this.studentService.addStudent(studentEntity);
           return new ResponseEntity<>(new StatusDTO(1, "Student Added Successfully", StudentTransformer.getStudentDto(studentEntity)), HttpStatus.CREATED);
       }catch (Exception e){
           e.printStackTrace();
          return new ResponseEntity<>(new StatusDTO(0,"Exception Accured"+e),HttpStatus.OK);
       }
    }//end student add controllers


    //update Student Entity
    @PutMapping("/update")
    public  ResponseEntity<StatusDTO> updateStudent(@ModelAttribute StudentDto studentDto){
        try {
            StudentEntity studentEntity = this.studentService.getStudent(Long.parseLong(studentDto.getId()));
            if(studentEntity !=null){
                StudentEntity stdEntity2 = StudentTransformer.getStudentEntity(studentDto);
                this.studentService.updateStudent(stdEntity2);
                return new ResponseEntity<>(new StatusDTO(1,"Student Updated Successfully"),HttpStatus.OK);
            }else{
                return new ResponseEntity<>(new StatusDTO(0,"Student  Not Found !!"),HttpStatus.NOT_FOUND);
            }
        }catch (Exception e){
            e.printStackTrace();
        return new ResponseEntity<>(new StatusDTO(0,"Exception Accured"+e),HttpStatus.OK);
        }

    }//end of Update Student Entity

    //get single user
    @GetMapping("/{studentId}")
    ResponseEntity<StatusDTO> getStudent(@PathVariable("studentId") Long studentId){
        try{
            StudentEntity studentEntity = this.studentService.getStudent(studentId);
            return new ResponseEntity<>(new StatusDTO(1,"Student Found Succssfully",StudentTransformer.getStudentDto(studentEntity)),HttpStatus.OK);
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseEntity<>(new StatusDTO(0,"Student Not Found !!"+e),HttpStatus.OK);
        }
    }

    //Delete Student
    @DeleteMapping("/{studentId}")
    ResponseEntity<StatusDTO> deleteStudent(@PathVariable("studentId") Long studentId){
        try{
            StudentEntity studentEntity = this.studentService.getStudent(studentId);
            if(studentEntity==null){
                return new ResponseEntity<>(new StatusDTO(0,"Student Not Found!!"+studentId),HttpStatus.NOT_FOUND);
            }else {
                this.studentService.deleteStudent(studentId);
            }
        }catch(Exception e){
            return new ResponseEntity<>(new StatusDTO(0,"Exception Accured !!"+e.getMessage()),HttpStatus.OK);
        }
        return new ResponseEntity<>(new StatusDTO(1,"Student Deleted Successfully!"),HttpStatus.OK);

    }

    //get All Students
    @GetMapping("/all")
     public List<StudentDto> getALlStudents(){
            List<StudentEntity> allStudentEntities = this.studentService.getAllStudentEntities();
            return StudentTransformer.getAllStudentDtos(allStudentEntities);
    }


}
