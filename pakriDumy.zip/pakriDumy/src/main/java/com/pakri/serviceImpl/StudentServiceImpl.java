package com.pakri.serviceImpl;

import com.pakri.entities.StudentEntity;
import com.pakri.repository.StudentRepository;
import com.pakri.services.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentRepository studentRepository;

    @Override
    public StudentEntity addStudent(StudentEntity studentEntity) {
        return this.studentRepository.save(studentEntity);
    }

    @Override
    public StudentEntity updateStudent(StudentEntity studentEntity) {

        if(studentEntity.getId() !=null){
            Optional<StudentEntity> studentEntityId = this.studentRepository.findById(studentEntity.getId());
            if(studentEntityId == null){
                return null;
            }
            StudentEntity updateStudentEntity = studentRepository.save(studentEntity);
            return updateStudentEntity;
        }
        return null;
    }

    @Override
    public StudentEntity getStudent(Long studentEntityId) {
        return this.studentRepository.findById(studentEntityId).get();
    }

    @Override
    public List<StudentEntity> getAllStudentEntities() {
        List<StudentEntity> allStudents = this.studentRepository.findAll();
        return allStudents;
    }

    @Override
    public void deleteStudent(Long studentEntityId) {
        StudentEntity studentEntity = this.studentRepository.findById(studentEntityId).get();
        this.studentRepository.delete(studentEntity);
    }
}
