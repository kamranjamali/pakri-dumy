package com.pakri.serviceImpl;

import com.pakri.entities.SystemSetupEntity;
import com.pakri.repository.SystemSetupRepository;
import com.pakri.services.SystemSetupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import javax.transaction.Transactional;
import java.util.List;
import java.util.Locale;

@Service
public class SystemSetupServiceImpl implements SystemSetupService {


    @Autowired
    private SystemSetupRepository systemSetupRepository;

    @Override
    public SystemSetupEntity addSystemEntity(SystemSetupEntity systemSetupEntity) {
        return this.systemSetupRepository.save(systemSetupEntity);
    }

    @Override
    public SystemSetupEntity getSystemSetupEntity(Long systemSetupEntityId) {
        SystemSetupEntity systemSetupEntity = this.systemSetupRepository.findById(systemSetupEntityId).get();
        return systemSetupEntity;
    }

    @Override
    @Transactional
    public void deleteSystemSetupEntity(Long systemSetupEntityId) {
        this.systemSetupRepository.deleteById(systemSetupEntityId);
    }

    @Override
    public List<SystemSetupEntity> getAllSystemSetupEntities() {
        List<SystemSetupEntity> listOfSystemSetup = this.systemSetupRepository.findAll();
        return listOfSystemSetup;
    }

    @Override
    @Transactional
    public void deleteAllEntities(List<SystemSetupEntity> setupEntityList) {
        for (SystemSetupEntity setupEntity : setupEntityList) {
            this.systemSetupRepository.delete(setupEntity);
        }
    }

    @Override
    public List<SystemSetupEntity> findAllByStudentEntityId(Long studentId) {
        return systemSetupRepository.findAllByStudentEntityId(studentId);
    }




}
