package com.pakri.transformer;

import com.pakri.dto.StudentDto;
import com.pakri.entities.StudentEntity;

import java.util.ArrayList;
import java.util.List;

public class StudentTransformer {

    // get student entity from  Dto
    public  static StudentEntity getStudentEntity(StudentDto studentDto){
        StudentEntity studentEntity = new StudentEntity();

        if(studentDto.getId() !=null){
            studentEntity.setId(Long.parseLong(studentDto.getId()));
        }

        if(studentDto.getName() !=null){
            studentEntity.setName(studentDto.getName());
        }

        if(studentDto.getRollNo() !=null){
            studentEntity.setRollNo(studentDto.getRollNo());
        }
        return studentEntity;
    }//end of Student Entity method

    //get Dto from Student Entity
    public static StudentDto getStudentDto(StudentEntity studentEntity){

        StudentDto studentDto = new StudentDto();

        if(studentEntity.getId() !=null){
            studentDto.setId(studentEntity.getId().toString());
        }

        if(studentEntity.getName() !=null){
            studentDto.setName(studentEntity.getName());
        }

        if(studentEntity.getRollNo() !=null){
            studentDto.setRollNo(studentEntity.getRollNo());
        }

        return studentDto;
    }//end of Student Dto method


    //get all StudentDto List
    public static List<StudentDto> getAllStudentDtos(List<StudentEntity> studentEntityList) {
        List<StudentDto> studentDtos=new ArrayList<>();

        if(studentEntityList !=null && studentEntityList.size() > 0){
            studentEntityList.forEach(student->{
                studentDtos.add(StudentTransformer.getStudentDto(student));
            });
        }
        return studentDtos;
    }//end of  List Students Dto

}
