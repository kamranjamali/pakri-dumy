package com.pakri.transformer;

import com.pakri.dto.StudentDto;
import com.pakri.dto.SystemSetupDto;
import com.pakri.entities.StudentEntity;
import com.pakri.entities.SystemSetupEntity;
import com.pakri.utils.DateUtil;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SystemSetupTransformer {


    //    //get entity method
//    //get entity from transformer
    public static SystemSetupEntity getSystemSetupEntity(SystemSetupDto systemSetupDto) {

        SystemSetupEntity systemSetupEntity = new SystemSetupEntity();

        if (systemSetupDto.getId() != null) {
            systemSetupEntity.setId(Long.parseLong(systemSetupDto.getId()));
        }

        if (systemSetupDto.getName() != null) {
            systemSetupEntity.setName(systemSetupDto.getName());
        }

        if (systemSetupDto.getSize() != null) {
            systemSetupEntity.setSize(Long.parseLong(systemSetupDto.getSize()));
        }

        if (systemSetupDto.getType() != null) {
            systemSetupEntity.setType(systemSetupDto.getType());
        }

        if (systemSetupDto.getItemWeight() != null) {
            systemSetupEntity.setItemWeight(Double.parseDouble(systemSetupDto.getItemWeight()));
        }

        if (systemSetupDto.getEstimateDate() != null) {
            systemSetupEntity.setEstimateDate(DateUtil.stringToDate(systemSetupDto.getEstimateDate()));
        }

        if(systemSetupDto.getStudentDto().getId() != null){
            StudentEntity studentEntity = new StudentEntity();
            studentEntity.setId((Long.parseLong(systemSetupDto.getStudentDto().getId())));
            systemSetupEntity.setStudentEntity(studentEntity);
        }

        return systemSetupEntity;
    }

    static int  i=1;
    //get  Dtos from Entity
    public static SystemSetupDto getSystemSetupDto(SystemSetupEntity systemSetupEntity) {

        SystemSetupDto systemSetupDto = new SystemSetupDto();

        if (systemSetupEntity.getId() != null) {
            systemSetupDto.setId(systemSetupEntity.getId().toString());
        }

        if (systemSetupEntity.getName() != null) {
            systemSetupDto.setName(systemSetupEntity.getName());
        }

        if (systemSetupEntity.getSize() != null) {
            systemSetupDto.setSize(systemSetupEntity.getSize().toString());
        }

        if (systemSetupEntity.getType() != null) {
            systemSetupDto.setType(systemSetupEntity.getType());
        }

        if (systemSetupEntity.getItemWeight() != null) {
            systemSetupDto.setItemWeight(systemSetupEntity.getItemWeight().toString());
        }

        if (systemSetupEntity.getEstimateDate() != null) {
            systemSetupDto.setEstimateDate(DateUtil.dateToString(systemSetupEntity.getEstimateDate()));
        }


        String res = String.format(Locale.getDefault(), "0%03d"+i);
        System.out.println("System- "+res+"-HYD ");
        systemSetupDto.setGenerateCode(res);
        i++;

//        if(systemSetupEntity.getStudentEntity().getId() !=null){
//            SystemSetupDto setupDto = new SystemSetupDto();
//            setupDto.setId(systemSetupEntity.getId().toString());
//            systemSetupDto.setStudentDto();
//
//        }
        return systemSetupDto;
    }


    //list of SystemSetupDtos
    public static List<SystemSetupDto> getAllStudentDtos(List<SystemSetupEntity> systemSetupEntities) {
        List<SystemSetupDto> systemSetupDtos = new ArrayList<>();

        if (systemSetupEntities != null && systemSetupEntities.size() > 0) {
            systemSetupEntities.forEach(student -> {
                systemSetupDtos.add(SystemSetupTransformer.getSystemSetupDto(student));
            });
        }
        return systemSetupDtos;
    }//end of  List Students Dto


}
